using EmployeeVacationApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeVacationApp.Controllers
{
    public class HomeController : Controller
    {
        static private List<Employee> employees;

        public HomeController()
        {
            if (employees == null)
            {
                employees = new List<Employee>();
                for (int i = 0; i < 10; i++) {
                    employees.Add(new HourlyEmployee(){ name="HourlyEmp"+i,Id="HE"+i});
                    employees.Add(new SalariedEmployee() { name = "SalariedEmp" + i , Id = "SE" + i});
                    employees.Add(new Manager() { name = "Manager" + i, Id = "MG" + i });
                }
                
            }

        }

        public IActionResult Index()
        {
            return View(employees);
        }
        [HttpPost]
        public IActionResult Work(string id,int days)
        {
            
            GetEmployeeById(id).Work(days);

            return RedirectToAction(nameof(Index));
            
        }
        private Employee GetEmployeeById(string id)
        {
          
            return employees.FirstOrDefault(e => e.Id == id);
        }
        [HttpPost]
        public IActionResult TakeVacation(string id,float days)
        {
            GetEmployeeById(id).TakeVacation(days);

            return RedirectToAction(nameof(Index));
        }
       

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
