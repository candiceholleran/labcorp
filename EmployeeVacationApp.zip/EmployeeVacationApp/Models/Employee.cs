﻿namespace EmployeeVacationApp.Models
{
    // Models/Employee.cs
    public class Employee
    {
        public string Id { get; set; }
        public string name { get; set; }
        public float VacationDays { get; protected set; } = 0;
        public int WorkDays { get;  set; } = 0;
        public virtual void Work(int days)
        {
            //store number of days worked
            WorkDays = days;
        }

        public virtual void TakeVacation(float days)
        {
            //subtract vacation days taken
            VacationDays = VacationDays - days;
        }
    }
}

