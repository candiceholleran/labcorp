﻿namespace EmployeeVacationApp.Models
{
    public class HourlyEmployee : Employee
    {
        public HourlyEmployee()
        {
            VacationDays = 0; 
        }

        public override void Work(int days)
        {
            base.Work(days);
            if (days >= 260)
            {
                VacationDays = 10;
            }
        }
    }

}
