﻿namespace EmployeeVacationApp.Models
{
    public class Manager : SalariedEmployee
    {
        public Manager()
        {
            VacationDays = 0; 
        }

        public override void Work(int days)
        {
            base.Work(days);
            if (days >= 260)
            {
                VacationDays = 30;
            }
        }
    }
}
